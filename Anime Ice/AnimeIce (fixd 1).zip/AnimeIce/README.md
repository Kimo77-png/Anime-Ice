# ❄️ AnimeIce — Native Android App

A native Android anime streaming app with Ice UI.  
Episodes open in a fullscreen WebView — no scraping, no backend, no hosting.

---

## 🚀 How to get your APK

### Step 1 — Upload to GitHub
1. Create a new repository on GitHub (name it `AnimeIce`)
2. Upload all these files to it (drag & drop works)
3. That's it — GitHub Actions will **automatically start building**

### Step 2 — Download your APK
1. Go to your repo on GitHub
2. Click the **Actions** tab
3. Click the latest workflow run
4. Scroll down to **Artifacts**
5. Download **AnimeIce-debug-X**
6. Extract the zip → install the `.apk` on your phone

> ⚠️ Before installing: go to Settings → Security → Allow unknown sources

---

## 📱 How the app works

```
Ice UI (index.html) loads in a native WebView
         ↓
User taps an anime card
         ↓
Detail modal shows — pick a source (Animelek / OkAnime / Gogo)
         ↓
PlayerActivity opens fullscreen
         ↓
Anime site loads in fullscreen WebView (landscape, nav hidden)
         ↓
User watches — looks 100% native
```

---

## 📁 Project Structure

```
AnimeIce/
├── .github/workflows/build.yml     ← Auto-builds APK
├── app/src/main/
│   ├── assets/index.html           ← Full Ice UI (edit this for design)
│   ├── java/com/animeice/
│   │   ├── SplashActivity.java     ← Boot screen
│   │   ├── MainActivity.java       ← Main WebView + JS bridge
│   │   └── PlayerActivity.java     ← Fullscreen episode player
│   ├── res/                        ← Icons, layouts, colors
│   └── AndroidManifest.xml
└── app/build.gradle
```

---

## 🎨 Customizing

| What | Where |
|------|-------|
| Change design / colors | `assets/index.html` |
| Add more anime sites | `SOURCES` object in `index.html` |
| Change app name | `res/values/strings.xml` |
| Change app icon | `res/drawable/ic_launcher_foreground.xml` |
| Change player behavior | `PlayerActivity.java` |

---

## ⚡ Adding more sources

In `index.html` find the `SOURCES` object and add your site:

```js
const SOURCES = {
  animelek:  (title) => `https://animelek.me/?search=${encodeURIComponent(title)}`,
  okanime:   (title) => `https://okanime.tv/search?q=${encodeURIComponent(title)}`,
  gogoanime: (title) => `https://gogoanime3.co/search.html?keyword=${encodeURIComponent(title)}`,
  // Add yours:
  anime4up:  (title) => `https://anime4up.cam/?search_param=animes&s=${encodeURIComponent(title)}`,
};
```

Then add a button for it in the detail modal HTML section.

---

Built with ❄️ Ice UI — V2 شتاء
