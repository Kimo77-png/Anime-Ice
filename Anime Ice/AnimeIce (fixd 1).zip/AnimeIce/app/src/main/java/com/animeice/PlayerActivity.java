package com.animeice;

import android.annotation.SuppressLint;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class PlayerActivity extends AppCompatActivity {

    private WebView playerWebView;
    private ProgressBar progressBar;
    private FrameLayout fullscreenContainer;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Keep screen on while watching
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // Force landscape + fullscreen
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );

        setContentView(R.layout.activity_player);

        playerWebView       = findViewById(R.id.player_webview);
        progressBar         = findViewById(R.id.player_progress);
        fullscreenContainer = findViewById(R.id.fullscreen_container);
        ImageButton backBtn = findViewById(R.id.player_back);
        TextView titleView  = findViewById(R.id.player_title);

        String url   = getIntent().getStringExtra("url");
        String title = getIntent().getStringExtra("title");

        if (title != null && !title.isEmpty()) {
            titleView.setText(title);
        }

        // ---- WebView settings ----
        WebSettings s = playerWebView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        // Desktop-class UA so sites don't block
        s.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/120.0.0.0 Mobile Safari/537.36"
        );

        // ---- ChromeClient — handles fullscreen video ----
        playerWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                fullscreenContainer.addView(view);
                fullscreenContainer.setVisibility(View.VISIBLE);
                playerWebView.setVisibility(View.GONE);
                backBtn.setVisibility(View.GONE);
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;
                fullscreenContainer.setVisibility(View.GONE);
                fullscreenContainer.removeView(customView);
                customView = null;
                customViewCallback.onCustomViewHidden();
                playerWebView.setVisibility(View.VISIBLE);
                backBtn.setVisibility(View.VISIBLE);
            }

            @Override
            public View getVideoLoadingProgressView() {
                return getLayoutInflater().inflate(R.layout.video_loading, null);
            }
        });

        // ---- WebViewClient ----
        playerWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                titleView.setVisibility(View.GONE); // hide title once loaded

                // Inject CSS to hide site nav/header/footer for cleaner look
                String css =
                    "header,nav,.header,.navbar,.nav-bar,.site-header," +
                    ".top-bar,.topbar,.breadcrumb,footer,.footer," +
                    ".site-footer,.ads,.advertisement,.ad-container," +
                    "#header,#nav,#footer,#sidebar { display:none!important; }" +
                    "body { margin:0!important; padding:0!important; }" +
                    "video { width:100vw!important; height:100vh!important; }";

                view.evaluateJavascript(
                    "(function(){" +
                    "  var s=document.createElement('style');" +
                    "  s.innerHTML='" + css + "';" +
                    "  document.head.appendChild(s);" +
                    "})();", null);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                // Stay in the WebView
                return false;
            }
        });

        // ---- Back button ----
        backBtn.setOnClickListener(v -> finish());

        // ---- Load URL ----
        if (url != null && !url.isEmpty()) {
            playerWebView.loadUrl(url);
        } else {
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            playerWebView.getWebChromeClient().onHideCustomView();
        } else if (playerWebView.canGoBack()) {
            playerWebView.goBack();
        } else {
            finish();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        playerWebView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        playerWebView.onPause();
    }

    @Override
    protected void onDestroy() {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        playerWebView.destroy();
        super.onDestroy();
    }
}
