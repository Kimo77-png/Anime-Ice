# AnimeIce ProGuard rules
-keep class com.animeice.** { *; }
-keepclassmembers class com.animeice.MainActivity$AndroidBridge {
    public *;
}
